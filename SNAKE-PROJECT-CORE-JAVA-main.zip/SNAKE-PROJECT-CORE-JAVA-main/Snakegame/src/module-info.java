/**
 * 
 */
/**
 * 
 */
module Snakegame {
	requires java.desktop;
}