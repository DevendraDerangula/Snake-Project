package main;

public class GamePlayer {
public static void main(String[] args) {
	GameFrame.Frame();
	
	
	
}
}
